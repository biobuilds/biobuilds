Mapping test data derived from the "example" directory in the bowtie2
sources. "reads_1.fq" and "reads_2.fq" are the first 1000 reads from the
original FASTQ data files (generated using 'head -n4000').
